﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Opdracht_Applicatie_PT
{
    public partial class frmOpdrachtApplicatie : Form
    {
        public frmOpdrachtApplicatie()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try //error melding.
            {
                lbxAdvies.Items.Clear(); // verwijdert het geheel van listbox.

                int eerste = int.Parse(txtEerste.Text); // verandert string naar int.
                int tweede = int.Parse(txtTweede.Text); // verandert string naar int.
                int stap = int.Parse(txtStapgroote.Text); // verandert string naar int.
                string groterKleine = ""; // string voor grote dan en kleine dan.
                string rekenkundig = ""; // string voor plus of min.
                string forlus = ""; // string voor forlus.
                string whileLus = ""; // string voor while lus.
                string whileLus2 = ""; // string voor while lus. 
                string rekenkundig2 = ""; // string voor plus of min.

                if (eerste < tweede && rdbKleinerDan.Checked || eerste > tweede && rdbGroterDan.Checked) // code voor een error melding bij verkeerde button.
                {




                    if (rdbKleinerDan.Checked || rdbGroterDan.Checked) // code voor een error melding bij geen keuze gemaakt groter of kleiner.
                    {


                        if (rdbFor.Checked || rdbWhile.Checked) // error melding voor geen keuze gemaakt (for of while lus).
                        {

                            if (rdbIs.Checked) // error melding voor geen = button aan te vinken.
                            {


                                if (rdbGroterDan.Checked) // als radio button GroterDan is gevinkt dan is string groterKleine >.
                                {
                                    groterKleine = ">";
                                }

                                if (rdbKleinerDan.Checked) // als radio button KleinerDan is gevinkt dan is string groterKleine <.
                                {
                                    groterKleine = "<";
                                }

                                if (rdbPlus.Checked) // als radio button plus is gevinkt dan is string rekenkundig +=.
                                {
                                    rekenkundig = "+=";
                                }
                                if (rdbPlus.Checked && stap == 1) // als de stap groote gelijk is aan 1 dan is de string rekenkudige ++.
                                {
                                    rekenkundig = "++";
                                }

                                if (rdbMin.Checked)// als radio button min is gevinkt dan is string rekenkundige -=.
                                {
                                    rekenkundig = "-=";
                                }
                                if (rdbMin.Checked && stap == 1) // als de stap groote gelijk is aan 1 dan is de string rekenkudige --.w
                                {
                                    rekenkundig = "--";
                                }

                                if (rdbFor.Checked)// als de radio button for is gevinkt dan gaat hij forlus op de listbox printen 
                                {
                                    if (stap == 1) // als de stap groote gelijk is aan 1 dan wordt de onderste regel geprint.
                                    {
                                        forlus = "for (int i = " + eerste + "; i " + groterKleine + tweede + "; i " + rekenkundig + ")";

                                    }
                                    if (stap > 1) // als de stap groote grooter is dan 1 dan wordt de ondersre regel geprint.
                                    {
                                        forlus = "for (int i = " + eerste + "; i " + groterKleine + tweede + "; i " + rekenkundig + stap + ")";

                                    }
                                    lbxAdvies.Items.Add(forlus); // code voor printen op de listbox.
                                    lbxAdvies.Items.Add("{");// code voor printen op de listbox.
                                    lbxAdvies.Items.Add("}");// code voor printen op de listbox.
                                }

                                if (rdbWhile.Checked) //  als de radio button for is gevinkt dan gaat hij whilelus op de listbox printen 
                                {
                                    whileLus = "int i = " + eerste + ";";
                                    whileLus2 = "while (i" + groterKleine + tweede + ")";

                                    if (stap > 1) // als de stap groote grooter is dan 1 dan wordt de ondersre regel geprint.
                                    {
                                        rekenkundig2 = " i" + rekenkundig + stap + ";";
                                    }
                                    if (stap == 1)// als de stap groote gelijk is aan 1 dan wordt de onderste regel geprint.
                                    {
                                        rekenkundig2 = "i" + rekenkundig + ";";
                                    }

                                    lbxAdvies.Items.Add(whileLus);// code voor printen op de listbox.
                                    lbxAdvies.Items.Add(whileLus2);// code voor printen op de listbox.
                                    lbxAdvies.Items.Add("{");// code voor printen op de listbox.
                                    lbxAdvies.Items.Add(rekenkundig2);// code voor printen op de listbox.
                                    lbxAdvies.Items.Add("}");// code voor printen op de listbox.
                                }

                            }
                            else
                            {
                                lbxAdvies.Items.Clear();
                                MessageBox.Show(" Error, u bent vergeten om op de button = te drukken!! "); // dit moet er geprint worden bij de error melding.
                            }
                        }
                        else
                        {
                            lbxAdvies.Items.Clear();
                            MessageBox.Show("Error u bent vergeten om een keuze te maken!! ");// dit moet er geprint worden bij de error melding.

                        }
                    }
                    else
                    {
                        lbxAdvies.Items.Clear();
                        MessageBox.Show("U bent vergeten een keuze te maken (kleiner of groter dan) !!");// dit moet er geprint worden bij de error melding.
                    }

                }
                else
                {
                    lbxAdvies.Items.Clear();
                    MessageBox.Show("De buttons (< of >) zijn niet goed geselcteerd met het gegeven beginwaarde en eindwaarde !!");// dit moet er geprint worden bij de error melding.
                }


            }


            catch
            {
                MessageBox.Show("Error probeer opnieuw!!");// dit moet er geprint worden bij de error melding.
            }
        }
    }
}
